<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Halaman Home</title>

</head>
<body>
    <h1>Selamat Datang di Website Saya</h1>

</body>
</html>